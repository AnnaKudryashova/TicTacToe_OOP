import game.Game;

public class Main {

    public static void main(String[] args) {
	Game gameInstance = new Game();
	gameInstance.initGame();
    }
}